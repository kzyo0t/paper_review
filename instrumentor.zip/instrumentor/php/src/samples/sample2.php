<?php


function helloWorld() {
   echo "HelloWorld!\n";
}

if (1) {
   helloWorld();
}
