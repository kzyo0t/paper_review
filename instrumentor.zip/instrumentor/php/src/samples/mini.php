<?php

function reLu(float $x):float {
   if ($x <= 0)
      return 0;
   
   return $x;
}
