<?php

namespace App;

class X {
   public function doX() {
      return 1;
   }
}

